// calculator.h

#ifndef CALCULATOR_H
#define CALCULATOR_H

float evaluateRPN(char* expr, float x);

#endif
